from config import client
from app import app
from bson.json_util import dumps
from flask import request, jsonify, make_response
import json

db = client['Employee']

collection = db['emp_info']

user_info = {"emp_id": 101,
             "name": "Bhagya",
             "age": 22,
             "gender": "female",
             "phone": 94838732801,
             "city": "Pune",
             "email": "bhagya@gmail.com"}
# print(type(user_info))
# collecion.insert_one(user_info)

@app.route("/insert_info", methods = ["POST"])
def insert_user():
    user = request.get_json()
    data = collection.find()
    res = [each_record for each_record in data if user["emp_id"] == each_record["emp_id"]]
    if res:
        results = make_response({"Existing Employee Id"}, 406)
        return results
    if is_instance(user, type(user_data)):
        collection.insert_one(user)
        results = make_response({"Employee info added successfully"}, 201)
        return results
    else:
        results = make_response({"Please enter valid info"}, 406)

@app.route("/get_user/<id>", methods = ["GET"])
def get_user(id):
    us1 = collection.find_one({"emp_id": int(id)})
    if us1:
        results = make_response(jsonify(user))
        return results
    else:
        results = make_response({"Employee data not found"}, 404)
        return results


@app.route("/update_record/<id>", methods = ["PUT"])
def update_record(id):
    req = request.get_json()
    available = collection.find_one({"emp_id": int(id)})
    if available:
        new_user = {"$set": req}
        collection.update_one({"emp_id": int(id)}, new_user)
        results = make_response({"msg": "Employee info updated successfully..."}, 200)
        return results
    else:
        results = make_response({"Please enter valid employee id"}, 404)
        return results

@app.route("/delete_record/<id>", methods = ["DELETE"])
def delete_data(id):
    us2 = collection.find_one({"emp_id": int(id)})
    if us2:
        collection.delete_one({"emp_id": int(id)})
        results = make_response({"Employee data deleted successfully..."}, 200)
        return results
    else:
        results = make_response({"Employee not found"}, 404)
        return results


# @app.route("/display", methods = ["GET"])
# def disp_data():
#     data = collection.find()
#     for record in data:
#         yield make_response(jsonify(record), 200)

#     return make_response({"Displayed Successfully..."})